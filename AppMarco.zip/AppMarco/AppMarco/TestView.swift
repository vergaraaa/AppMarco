//
//  TestView.swift
//  AppMarco
//
//  Created by user191983 on 9/6/21.
//

import SwiftUI

struct TestView: View {
    var body: some View {
        Text("Hello Mundo!")
    }
}

struct TestView_Previews: PreviewProvider {
    static var previews: some View {
        TestView()
    }
}
