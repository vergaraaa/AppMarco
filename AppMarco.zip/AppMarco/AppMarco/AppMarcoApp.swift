//
//  AppMarcoApp.swift
//  AppMarco
//
//  Created by user191983 on 8/29/21.
//

import SwiftUI

@main
struct AppMarcoApp: App {
    var body: some Scene {
        WindowGroup {
            //MainView()
            LoginView()
        }
    }
}
