//
//  RecorridosVirtuales.swift
//  AppMarco
//
//  Created by user195902 on 9/5/21.
//

import SwiftUI

struct RecorridoVirtual:Identifiable{
    var id = UUID()
    var arrImages: [String]
    var sLink: String
}
