//
//  ComprarBoletosView.swift
//  AppMarco
//
//  Created by user188940 on 9/6/21.
//

import SwiftUI

struct ComprarBoletosView: View {
    var body: some View {
        Text("En construcción")
    }
}

struct ComprarBoletosView_Previews: PreviewProvider {
    static var previews: some View {
        ComprarBoletosView()
    }
}
